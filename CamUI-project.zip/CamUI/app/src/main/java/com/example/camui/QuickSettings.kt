package com.example.camui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun QuickPanel(
    ratioIdx: Int,
    onRatio: (Int) -> Unit,
    ultraHdr: Boolean,
    onUltraHdr: () -> Unit,
    stabilization: Boolean,
    onStabilization: () -> Unit,
    metering: String,
    onMetering: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CamColors.Panel)
            .border(0.5.dp, CamColors.Stroke, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hàng 1: Aspect Ratio
        Text("Aspect Ratio", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            aspectRatios.forEachIndexed { i, (label, _) ->
                Chip(label, i == ratioIdx, { onRatio(i) }, Modifier.weight(1f))
            }
        }

        // Hàng 2: 3 thẻ tính năng lớn
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FeatureCard("Rendering Engine  ›", true, false, {}, Modifier.weight(1f))
            FeatureCard("Ultra HDR", ultraHdr, true, onUltraHdr, Modifier.weight(1f))
            FeatureCard("Preview Stabilization", stabilization, true, onStabilization, Modifier.weight(1f))
        }

        // Hàng 3: 3 thẻ phụ
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallCard("Metering", metering, null, onMetering, Modifier.weight(1f))
            SmallCard("Toolbox", null, Icons.Default.Palette, {}, Modifier.weight(1f))
            SmallCard("Content Management", null, Icons.Default.Tune, {}, Modifier.weight(1f))
        }

        // Hàng 4: nút Settings
        Row(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(CamColors.Chip)
                .clickable(onClick = onSettings)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Settings  ›", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
        }
    }
}

@Composable
private fun FeatureCard(
    title: String,
    on: Boolean,
    showDot: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .height(84.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (on) CamColors.Yellow else CamColors.Chip)
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Text(
            title,
            color = if (on) Color.Black else Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            modifier = Modifier.align(Alignment.BottomStart)
        )
        if (showDot) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(if (on) Color.Black else Color(0x55FFFFFF))
            )
        }
    }
}

@Composable
private fun SmallCard(
    title: String,
    subtitle: String?,
    icon: ImageVector?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .height(72.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(CamColors.Chip)
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column(Modifier.align(Alignment.BottomStart)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            if (subtitle != null) {
                Text(subtitle, color = CamColors.Sub, fontSize = 11.sp)
            }
        }
        if (icon != null) {
            Icon(
                icon,
                contentDescription = title,
                tint = Color.White,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(20.dp)
            )
        }
    }
}
