package com.example.camui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class SettingItem(val title: String, val subtitle: String)

private val captureItems = listOf(
    SettingItem("Assistive Tools", "Grid Lines · Horizontal Level · Focus Peaking"),
    SettingItem("Focus & Lens", "Human Eye AF · Default Focal Length · Photo Orientation · Add ISZ/DCG Lens"),
    SettingItem("Capture & Storage", "Aspect Ratios · Multiple Exposure Count · Photo Quality · Auto Save · Save Location"),
    SettingItem(
        "Video",
        "Noise Reduction Level · Sharpening Level · Separate Photo and Video LUTs · Lock Lens · Lock White Balance · Video Save Path"
    )
)

private val imagingItems = listOf(
    SettingItem(
        "Photo mode settings",
        "Multi-frame denoise frames · Multi-frame denoise output scale · Noise Reduction Level · Sharpening Level"
    )
)

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(CamColors.Bg)
            .systemBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("Settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { SectionTitle("Capture") }
            items(captureItems) { SettingCard(it) }
            item { SectionTitle("Imaging") }
            items(imagingItems) { SettingCard(it) }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        color = CamColors.Sub,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp)
    )
}

@Composable
private fun SettingCard(item: SettingItem) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CamColors.Card)
            .clickable { }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(item.subtitle, color = CamColors.Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = CamColors.Sub)
    }
}
