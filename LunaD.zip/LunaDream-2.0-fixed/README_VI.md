# LunaDream 2.0 – bản sửa

Chỉ sửa **LunaDream 2.0**. LunaDream 1.5, UI và chức năng camera khác **không bị chỉnh sửa**.

## 1. LunaDream 2.0 nằm ở đâu
Toàn bộ thuật toán nằm trong `NightShotProcessor.kt` (repo `CamUI-src`):

| Thành phần | Hàm |
|---|---|
| Ghép khung / điều phối | `mergeFramesIntoUri` (`MergeMode.LUNA_DREAM_2_0`) |
| Căn chỉnh | `estimatePyramidalLucasKanade`, `buildGrayPyramid`, `detectShiTomasiFeatures`, `trackPyramidalLucasKanade`, `robustTranslationConsensus` |
| Hợp nhất thời gian | `fuseLunaDream20Frame` (mới) – 1.5 vẫn dùng `fuseLunaDreamFrameParallel` |
| Hoàn thiện | `applyLunaDream20FinishingPass` (mới, gộp denoise strength-2 + detail 2.0) |
| RawDream 2.0 (1 khung) | `processLunaDream20SingleFrame` |
| Kích thước 108MP | `PhotoOutputResolution.kt`, `PhotoOutputGeometry.kt` (không sửa) |

APK `Fujifilm-Mode-v1 (20).apk` (DEX, `.so`), `app.zip` (smali) và `CamUI-project.zip` được quét: **không chứa LunaDream**. Mã nguồn duy nhất là `CamUI-src`.

## 2. Nguyên nhân lỗi "xử lý xong nhưng báo chưa hoàn tất"
`applyLunaDream20DetailRecoveryParallel` luôn đọc `rowCount + 1` hàng ở stripe cuối, vượt chiều cao bitmap → `Bitmap.getPixels` ném `IllegalArgumentException`. Ngoại lệ bị bắt trong `mergeFramesIntoUri` → trả `false` → `CameraScreen` hiển thị "LunaDream chưa xử lý hoàn tất" dù đã chạy gần hết. Bản denoise song song và đường tuần tự đã xử lý biên đúng; chỉ bản detail song song thiếu. Đã sửa (đọc đúng số hàng còn lại + nhân bản hàng cuối). 1.5 không dùng hàm này nên không bị ảnh hưởng.

## 3. Thay đổi (giữ nguyên thuật toán và công thức)
- **Chất lượng:** bộ tích lũy ghép khung chuyển từ RGB_565 sang ARGB_8888 (cùng số pixel). Trước đây mỗi khung bị lượng tử hóa lại về 5/6/5 bit, làm mất lợi ích khử nhiễu và gây banding ở vùng tối. Nếu thiếu bộ nhớ thì tự lùi về RGB_565 như cũ. Không đổi độ phân giải, không sinh chi tiết giả.
- **Tốc độ/CPU:** denoise + detail chạy một lượt (đọc/ghi bitmap 1 lần thay vì 2); đọc/ghi stripe kế tiếp chồng lên tính toán; chia việc theo chunk động (tối đa 6 luồng, trước là 4); dùng lại bộ đệm thay vì cấp phát lại mỗi stripe; bỏ `minOf/maxOf` vararg trong vòng lặp pixel.
- **Pipeline:** giải mã trước khung kế tiếp trong lúc căn chỉnh/ghép khung hiện tại, chỉ khi `ActivityManager` báo đủ RAM trống.
- **RawDream 2.0 (1 khung):** dùng pass detail song song đã sửa thay vì tuần tự.

`diff`: `patches/LunaDream2.0.diff`. Bản gốc: `original/NightShotProcessor.kt`.

## 4. Kiểm chứng đã làm và chưa làm
Đã làm (Python/numpy, `verification/run_all.sh`): tái hiện lỗi stripe cuối; bản sửa khớp **từng bit** với đường tuần tự; bản gộp denoise+detail khớp từng bit với hai pass riêng (nhiều kích thước stripe/chunk, kể cả ảnh 3×3 và biên trên/dưới); ghép 8 khung theo stripe + đọc/ghi chồng nhau khớp từng bit với ghép toàn ảnh.

**Chưa làm được:** môi trường này không có Kotlin compiler, Android SDK hay thiết bị. Mã Kotlin **chưa được biên dịch hay chạy trên máy**, và mình **chưa đo** mức tăng tốc. Hãy chạy `gradle :app:testDebugUnitTest :app:assembleDebug` rồi chụp thử 2.0 trước khi phát hành. Mức tăng tốc thực tế cần đo qua log `FUJI_NIGHTSHOT` (đã in decode/align/fusion/detail/encode/publish ms).

## 5. Chưa sửa (cần quyết định/đo trên máy)
- Căn chỉnh dùng thumbnail 128px nên độ chính xác dịch khung ~vài pixel ở độ phân giải đầy đủ; tăng độ phân giải thumbnail sẽ cải thiện nhưng cần thử trên ảnh thật.
- `PhotoOutputResolution` kiểm tra bộ nhớ theo Java heap dù bitmap nằm ở native heap; trên máy heap nhỏ có thể từ chối 108MP. Hàm này dùng chung với 1.5 nên mình không đụng tới.
- Khung ghép có độ phân giải làm việc bị giới hạn theo heap rồi được nội suy lên 108MP (thiết kế hiện tại, giữ nguyên).

## 6. Dependency và build
Yêu cầu: JDK 17, Android SDK (compileSdk 36, minSdk 29), Gradle 8.11.1, AGP 8.10.1, Kotlin 2.0.21. Thư viện chính (khai báo trong `project/app/build.gradle.kts`): CameraX 1.6.2 (core, camera2, lifecycle, view, extensions), `androidx.exifinterface:1.3.7`, `androidx.core:core-ktx:1.15.0`, Compose BOM 2024.10.01. `NightShotProcessor.kt` dùng trực tiếp CameraX core, ExifInterface và kotlinx-coroutines.

Build (từ thư mục `project/`):

    gradle :app:testDebugUnitTest :app:assembleDebug :app:assembleRelease

APK nằm ở `app/build/outputs/apk/{debug,release}/`. Workflow CI tham chiếu: `project/build-camui.yml.reference`. `AndroidManifest.xml` cần giữ `android:largeHeap="true"`.
