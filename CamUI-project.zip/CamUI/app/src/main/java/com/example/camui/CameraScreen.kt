package com.example.camui

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.net.Uri
import android.provider.MediaStore
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.FilterCenterFocus
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size as GSize
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val zoomLevels = listOf(0.6f, 1.0f, 1.3f, 1.9f, 3.3f, 7.7f)
private val meteringModes = listOf("Center Weighted", "Matrix", "Spot")

@Composable
fun CameraScreen(onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val mainExecutor = remember { ContextCompat.getMainExecutor(context) }
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }

    // ---- Quyền camera ----
    var hasCam by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasCam = it
    }
    LaunchedEffect(Unit) {
        if (!hasCam) permLauncher.launch(Manifest.permission.CAMERA)
    }

    // ---- Trạng thái giao diện ----
    var mode by remember { mutableStateOf("Pro") }
    var front by remember { mutableStateOf(false) }
    var flash by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var timerSec by remember { mutableIntStateOf(0) }
    var countdown by remember { mutableIntStateOf(0) }
    var showGrid by remember { mutableStateOf(true) }
    var showHist by remember { mutableStateOf(true) }
    var showQuick by remember { mutableStateOf(false) }
    var ratioIdx by remember { mutableIntStateOf(1) }
    var zoomSel by remember { mutableFloatStateOf(1.0f) }
    var metering by remember { mutableIntStateOf(0) }
    var ultraHdr by remember { mutableStateOf(true) }
    var stabilization by remember { mutableStateOf(false) }
    var proSel by remember { mutableStateOf<String?>(null) }
    var evIndex by remember { mutableIntStateOf(0) }
    val sliderVals = remember { mutableStateMapOf("Tv" to 0.5f, "ISO" to 0.3f, "AF" to 0.5f, "AWB" to 0.5f) }

    // ---- Thông số đọc trực tiếp từ camera ----
    var iso by remember { mutableIntStateOf(0) }
    var shutterNs by remember { mutableLongStateOf(0L) }
    var focusDiopter by remember { mutableFloatStateOf(0f) }
    var hist by remember { mutableStateOf(IntArray(64)) }

    var camera by remember { mutableStateOf<Camera?>(null) }
    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var thumb by remember { mutableStateOf<ImageBitmap?>(null) }

    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    val imageCapture = remember {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
    }

    LaunchedEffect(flash) { imageCapture.flashMode = flash }

    // ---- Gắn camera ----
    LaunchedEffect(hasCam, front) {
        if (!hasCam) return@LaunchedEffect
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val provider = future.get()

            val previewBuilder = Preview.Builder()
            Camera2Interop.Extender(previewBuilder).setSessionCaptureCallback(
                object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureCompleted(
                        session: CameraCaptureSession,
                        request: CaptureRequest,
                        result: TotalCaptureResult
                    ) {
                        result.get(CaptureResult.SENSOR_SENSITIVITY)?.let { iso = it }
                        result.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { shutterNs = it }
                        result.get(CaptureResult.LENS_FOCUS_DISTANCE)?.let { focusDiopter = it }
                    }
                }
            )
            val preview = previewBuilder.build().also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            var lastHist = 0L
            analysis.setAnalyzer(analysisExecutor) { image ->
                try {
                    val now = System.currentTimeMillis()
                    if (now - lastHist > 120) {
                        lastHist = now
                        val plane = image.planes[0]
                        val buf = plane.buffer
                        val rowStride = plane.rowStride
                        val bins = IntArray(64)
                        var y = 0
                        while (y < image.height) {
                            var x = 0
                            while (x < image.width) {
                                bins[(buf.get(y * rowStride + x).toInt() and 0xFF) shr 2]++
                                x += 8
                            }
                            y += 8
                        }
                        hist = bins
                    }
                } finally {
                    image.close()
                }
            }

            val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            provider.unbindAll()
            camera = try {
                provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture, analysis)
            } catch (e: Exception) {
                Toast.makeText(context, "Không mở được camera: ${e.message}", Toast.LENGTH_LONG).show()
                null
            }
            evIndex = 0
            zoomSel = 1.0f
        }, mainExecutor)
    }

    // ---- Thumbnail ảnh vừa chụp ----
    LaunchedEffect(lastUri) {
        val uri = lastUri ?: return@LaunchedEffect
        thumb = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.loadThumbnail(uri, Size(256, 256), null).asImageBitmap()
            }.getOrNull()
        }
    }

    fun takePhoto() {
        if (mode == "Video") {
            Toast.makeText(context, "Chế độ Video mới có giao diện, chưa quay được", Toast.LENGTH_SHORT).show()
            return
        }
        if (camera == null) return
        scope.launch {
            if (timerSec > 0) {
                for (s in timerSec downTo 1) {
                    countdown = s
                    delay(1000)
                }
                countdown = 0
            }
            val name = "CAM_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CamUI")
            }
            val options = ImageCapture.OutputFileOptions.Builder(
                context.contentResolver,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            ).build()
            imageCapture.takePicture(
                options,
                mainExecutor,
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                        lastUri = output.savedUri
                        Toast.makeText(context, "Đã lưu vào Pictures/CamUI", Toast.LENGTH_SHORT).show()
                    }

                    override fun onError(exception: ImageCaptureException) {
                        Toast.makeText(context, "Lỗi chụp: ${exception.message}", Toast.LENGTH_LONG).show()
                    }
                }
            )
        }
    }

    // ---- Giá trị hiển thị ở Pro Controls ----
    val evStep = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0f
    val evText = if (evIndex == 0) "0" else "%+.1f".format(Locale.US, evIndex * evStep)
    val tvText = if (shutterNs > 0) {
        val s = shutterNs / 1_000_000_000.0
        if (s >= 0.5) "%.1f\"".format(Locale.US, s) else "1/${(1.0 / s).roundToInt()}"
    } else "—"
    val isoText = if (iso > 0) iso.toString() else "—"
    val afText = if (focusDiopter > 0.01f) "${(100f / focusDiopter).roundToInt()}cm" else "∞"
    val proItems = listOf(
        Triple("EV", evText, "EV"),
        Triple("Tv", tvText, "Tv"),
        Triple("ISO", isoText, "ISO"),
        Triple("AF", afText, "AF"),
        Triple("AWB", "Auto", "AWB")
    )

    // ================= GIAO DIỆN =================
    Box(
        Modifier
            .fillMaxSize()
            .background(CamColors.Bg)
            .systemBarsPadding()
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Thanh công cụ trên cùng
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CircleBtn(
                    icon = when (flash) {
                        ImageCapture.FLASH_MODE_ON -> Icons.Default.FlashOn
                        ImageCapture.FLASH_MODE_AUTO -> Icons.Default.FlashAuto
                        else -> Icons.Default.FlashOff
                    },
                    desc = "Flash",
                    onClick = {
                        flash = when (flash) {
                            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                            ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                            else -> ImageCapture.FLASH_MODE_OFF
                        }
                    }
                )
                CircleBtn(
                    Icons.Default.Timer, "Timer",
                    onClick = { timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 } },
                    tint = if (timerSec > 0) CamColors.Yellow else Color.White
                )
                CircleBtn(
                    Icons.Default.FilterCenterFocus, "Metering",
                    onClick = { metering = (metering + 1) % meteringModes.size }
                )
                CircleBtn(
                    Icons.Default.BarChart, "Histogram",
                    onClick = { showHist = !showHist },
                    tint = if (showHist) CamColors.Yellow else Color.White
                )
                CircleBtn(
                    Icons.Default.Settings, "Settings",
                    onClick = { showQuick = !showQuick },
                    tint = if (showQuick) CamColors.Yellow else Color.White
                )
            }

            Spacer8()

            // Khung ngắm
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .aspectRatio(aspectRatios[ratioIdx].second)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                ) {
                    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                    if (showGrid) {
                        Canvas(Modifier.fillMaxSize()) {
                            val c = Color(0x59FFFFFF)
                            for (i in 1..2) {
                                val x = size.width * i / 3f
                                val y = size.height * i / 3f
                                drawLine(c, Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
                                drawLine(c, Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
                            }
                        }
                    }
                    if (showHist) {
                        Histogram(
                            hist,
                            Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                                .size(110.dp, 56.dp)
                        )
                    }
                    if (!hasCam) {
                        Text(
                            "Cần cấp quyền Camera\n(chạm để cấp)",
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .align(Alignment.Center)
                                .clickable { permLauncher.launch(Manifest.permission.CAMERA) }
                        )
                    }
                }
            }

            // Thanh Zoom
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                zoomLevels.forEach { z ->
                    val selected = z == zoomSel
                    Text(
                        "${z}x",
                        color = if (selected) CamColors.Yellow else Color.White,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = if (selected) 16.sp else 14.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                val zs = camera?.cameraInfo?.zoomState?.value
                                val r = z.coerceIn(zs?.minZoomRatio ?: 1f, zs?.maxZoomRatio ?: 1f)
                                camera?.cameraControl?.setZoomRatio(r)
                                zoomSel = z
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }

            // Thanh trượt cho thông số đang chọn
            val sel = proSel
            if (sel != null) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(sel, color = CamColors.Yellow, fontWeight = FontWeight.Bold, modifier = Modifier.width(44.dp))
                    val colors = SliderDefaults.colors(
                        thumbColor = CamColors.Yellow,
                        activeTrackColor = CamColors.Yellow,
                        inactiveTrackColor = Color(0xFF3A3A3A)
                    )
                    if (sel == "EV") {
                        val range = camera?.cameraInfo?.exposureState?.exposureCompensationRange
                        val lo = range?.lower ?: 0
                        val hi = range?.upper ?: 0
                        if (hi > lo) {
                            Slider(
                                value = evIndex.toFloat(),
                                onValueChange = {
                                    val v = it.roundToInt()
                                    if (v != evIndex) {
                                        evIndex = v
                                        camera?.cameraControl?.setExposureCompensationIndex(v)
                                    }
                                },
                                valueRange = lo.toFloat()..hi.toFloat(),
                                steps = hi - lo - 1,
                                colors = colors
                            )
                        } else {
                            Text("Máy không hỗ trợ bù sáng", color = CamColors.Sub, fontSize = 13.sp)
                        }
                    } else {
                        Slider(
                            value = sliderVals[sel] ?: 0.5f,
                            onValueChange = { sliderVals[sel] = it },
                            colors = colors
                        )
                    }
                }
            }

            // Pro Controls
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                proItems.forEach { (key, value, label) ->
                    val active = proSel == key
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(CamColors.Glass)
                            .border(
                                0.5.dp,
                                if (active) CamColors.Yellow else CamColors.Stroke,
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { proSel = if (active) null else key }
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (mode == "Pro") {
                            Text(
                                value,
                                color = if (active) CamColors.Yellow else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                maxLines = 1
                            )
                        }
                        Text(label, color = CamColors.Sub, fontSize = 12.sp)
                    }
                }
            }

            // Khu vực chụp
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(CamColors.Glass),
                    contentAlignment = Alignment.Center
                ) {
                    val t = thumb
                    if (t != null) {
                        Image(
                            t, "Thư viện",
                            Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(Icons.Default.PhotoLibrary, "Thư viện", tint = Color.White)
                    }
                }
                Box(
                    Modifier
                        .size(76.dp)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(7.dp)
                        .clip(CircleShape)
                        .background(if (mode == "Video") Color(0xFFE53935) else Color.White)
                        .clickable { takePhoto() }
                )
                CircleBtn(
                    Icons.Default.FlipCameraAndroid, "Đổi camera",
                    onClick = { front = !front },
                    size = 56.dp
                )
            }

            // Thanh chuyển chế độ
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(28.dp))
                        .background(CamColors.Glass)
                        .border(0.5.dp, CamColors.Stroke, RoundedCornerShape(28.dp))
                        .padding(4.dp)
                ) {
                    listOf("Pro", "Photo", "Video").forEach { m ->
                        val selected = m == mode
                        Box(
                            Modifier
                                .width(92.dp)
                                .height(40.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(if (selected) CamColors.Yellow else Color.Transparent)
                                .clickable { mode = m },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                m,
                                color = if (selected) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // Bảng cài đặt nhanh
        if (showQuick) {
            QuickPanel(
                ratioIdx = ratioIdx,
                onRatio = { ratioIdx = it },
                ultraHdr = ultraHdr,
                onUltraHdr = { ultraHdr = !ultraHdr },
                stabilization = stabilization,
                onStabilization = { stabilization = !stabilization },
                metering = meteringModes[metering],
                onMetering = { metering = (metering + 1) % meteringModes.size },
                onSettings = {
                    showQuick = false
                    onOpenSettings()
                },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(start = 12.dp, end = 12.dp, top = 76.dp)
            )
        }

        // Đếm ngược hẹn giờ
        if (countdown > 0) {
            Text(
                "$countdown",
                color = Color.White,
                fontSize = 96.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

@Composable
private fun Spacer8() {
    Box(Modifier.height(8.dp))
}

@Composable
private fun Histogram(bins: IntArray, modifier: Modifier = Modifier) {
    Canvas(modifier.background(Color(0x66000000), RoundedCornerShape(6.dp))) {
        val max = (bins.maxOrNull() ?: 1).coerceAtLeast(1)
        val bw = size.width / bins.size
        bins.forEachIndexed { i, v ->
            val h = size.height * v / max
            drawRect(Color(0xCCFFFFFF), Offset(i * bw, size.height - h), GSize(bw, h))
        }
    }
}
